# Bundle spec template

bundle_name: example-bundle
skill_slug: example-skill-set
root_purpose: |
  Standard for safe changes in an example repository.
root_goal: |
  Preserve current behavior and contracts.

scope:
  - app code
  - shared utilities
  - integration points

core_rules:
  - Treat the codebase as contract-sensitive.
  - Make the smallest local reversible patch.
  - Do not change behavior unless the task requires it.

do_not_change:
  - request and response shapes
  - defaults and fallbacks
  - side effects and execution order

change_rules:
  - Keep scope narrow.
  - Avoid unrelated refactors.
  - Follow existing local patterns.

checks:
  - no out-of-scope changes
  - no unintended behavior changes

output_rules:
  - Return only changed code or a narrow diff.
  - Keep explanations short.

formatting_rules:
  - single quotes
  - trailing commas

openai_readme_intro: |
  This directory contains focused skill guides for the repository.
  Use AGENTS.md for global rules and read the skill files only when relevant.

agents_guide_intro: |
  This guide explains how to integrate the generated bundle into a repository.

skills:
  - filename: api-contract-safety.md
    title: API Contract Safety
    when_to_use: For request or response contracts and integration payloads.
    goal: Preserve API and payload contracts while making the smallest safe patch.
    rules:
      - Preserve field names and payload shapes unless task-required.
      - Preserve nullability and defaults unless task-required.
    safe_pattern:
      - Identify the current contract surface.
      - Change only the minimum local logic required.
      - Preserve compatibility by default.
    avoid:
      - broad contract refactors
      - incidental payload shape changes

  - filename: final-review-checklist.md
    title: Final Review Checklist
    when_to_use: As the final self-check before returning a patch.
    goal: Verify the change stayed narrow and safe.
    rules:
      - Check scope stayed local.
      - Check contracts and side effects stayed stable.
    safe_pattern:
      - Review the changed files.
      - Review runtime and contract impact.
    avoid:
      - shipping uncertain logic changes

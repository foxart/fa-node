# Design Notes

## Target structure

Generated bundles should use:

- `AGENTS.md`
- `AGENTS-GUIDE.md`
- `openai/README.md`
- `openai/skills/*.md`

## Split strategy

Put only always-on rules in `AGENTS.md`:

- purpose
- scope
- priorities
- short invariants
- short checks
- output expectations
- links to focused skill files

Put longer or task-specific guidance into `openai/skills/*.md`:

- routing
- graphql
- forms
- db queries
- finance
- shared components
- naming rules
- final review checklists

Put bundle navigation into `openai/README.md`.

## Efficiency guidance

- keep `AGENTS.md` compact
- avoid repeating detailed skill text in the root file
- prefer a few focused skill files over one giant policy document
- use explicit filenames that reveal scope quickly

---
name: agents-skill-scaffold-generator
description: generate reusable repository instruction bundles for ai coding agents. use when creating or updating a repository-level AGENTS.md plus openai/README.md and openai/skills/*.md guidance set for a specific stack, architecture, or safety policy.
---

# Agents Skill Scaffold Generator

Generate a compact instruction bundle for coding agents with this target structure:

- `AGENTS.md`
- `AGENTS-GUIDE.md`
- `openai/README.md`
- `openai/skills/*.md`

## Use this skill when

Use this skill when the user wants to:

- create a reusable repository instruction set
- split a long policy into a short root `AGENTS.md` plus focused skill guides
- standardize agent guidance across multiple stacks
- regenerate the same bundle shape for different repositories

## Workflow

1. Collect or infer the bundle specification.
2. Write the spec as YAML using `references/spec-template.md`.
3. Run `scripts/generate_bundle.py --spec <spec.yaml> --out <output-dir>`.
4. Return the generated bundle or package it if needed.

## Output rules

- Keep `AGENTS.md` short and always-on.
- Put longer, task-specific guidance into `openai/skills/*.md`.
- Put the index and usage notes into `openai/README.md`.
- Generate `AGENTS-GUIDE.md` with concrete install steps.
- Do not duplicate detailed skill content back into `AGENTS.md`.

## Resources

- Spec template: `references/spec-template.md`
- Design notes: `references/design-notes.md`
- Generator: `scripts/generate_bundle.py`

\
#!/usr/bin/env python3
import argparse
from pathlib import Path
import yaml


def md_list(items):
    return "\n".join(f"- {item}" for item in items)


def numbered_list(items):
    return "\n".join(f"{idx}. {item}" for idx, item in enumerate(items, start=1))


def build_agents(spec):
    skill_paths = [f"`openai/skills/{s['filename']}`" for s in spec["skills"]]
    sections = []

    sections.append("## Purpose\n\n" + spec["root_purpose"].strip() + "\n\nGoal: " + spec["root_goal"].strip())
    sections.append("## Scope\n\nApplies to:\n\n" + md_list(spec["scope"]))
    if spec.get("core_rules"):
        sections.append("## Core Rules\n\n" + md_list(spec["core_rules"]))
    if spec.get("do_not_change"):
        sections.append("## Do Not Change Unless Required\n\n" + md_list(spec["do_not_change"]))
    if spec.get("change_rules"):
        sections.append("## Change Rules\n\n" + md_list(spec["change_rules"]))
    if spec.get("formatting_rules"):
        sections.append("## Formatting Rules\n\n" + md_list(spec["formatting_rules"]))
    if spec.get("checks"):
        sections.append("## Checks\n\nBefore finishing, verify:\n\n" + md_list(spec["checks"]))
    if spec.get("output_rules"):
        sections.append("## Output Format\n\n" + md_list(spec["output_rules"]))
    sections.append("## Related Skills\n\nRead these only when relevant to the task:\n\n" + md_list(skill_paths))
    return "\n\n".join(sections) + "\n"


def build_openai_readme(spec):
    lines = [
        "# OpenAI Skills",
        "",
        spec["openai_readme_intro"].strip(),
        "",
        "Read the additional files only when the task matches their scope:",
        "",
    ]
    for skill in spec["skills"]:
        lines.append(f"- `{skill['filename']}` — {skill['when_to_use']}")
    lines.append("")
    return "\n".join(lines)


def build_skill_file(skill):
    sections = [
        f"# {skill['title']}",
        "",
        skill["when_to_use"].strip(),
        "",
        "## Goal",
        "",
        skill["goal"].strip(),
    ]
    if skill.get("rules"):
        sections.extend(["", "## Rules", "", md_list(skill["rules"])])
    if skill.get("safe_pattern"):
        sections.extend(["", "## Safe Pattern", "", numbered_list(skill["safe_pattern"])])
    if skill.get("avoid"):
        sections.extend(["", "## Avoid", "", md_list(skill["avoid"])])
    return "\n".join(sections) + "\n"


def build_agents_guide(spec):
    skill_filenames = [s["filename"] for s in spec["skills"]]
    layout = [
        "<repo-root>/",
        "  AGENTS.md",
        "  AGENTS-GUIDE.md",
        "  openai/",
        "    README.md",
        "    skills/",
    ] + [f"      {name}" for name in skill_filenames]

    lines = [
        f"# AGENTS Guide for {spec['bundle_name']}",
        "",
        spec["agents_guide_intro"].strip(),
        "",
        "## What You Are Installing",
        "",
        "- one root `AGENTS.md` for always-on rules",
        "- one `openai/README.md` index for focused guidance",
        "- focused skill files under `openai/skills/*.md`",
        "",
        "## Recommended Layout",
        "",
        "```text",
        *layout,
        "```",
        "",
        "## Step 1 — Copy the Files",
        "",
        "Copy these files into the repository root:",
        "",
        "- `AGENTS.md`",
        "- `AGENTS-GUIDE.md`",
        "- `openai/README.md`",
        "- all files under `openai/skills/`",
        "",
        "## Step 2 — Keep Root `AGENTS.md` Short",
        "",
        "Do not move detailed skill content into the root file.",
        "Keep always-on rules in `AGENTS.md` and task-specific guidance in `openai/skills/*.md`.",
        "",
        "## Step 3 — Use Skills by Task Type",
        "",
    ]
    for skill in spec["skills"]:
        lines.append(f"- `{skill['filename']}` → {skill['when_to_use']}")
    lines.extend([
        "",
        "## Step 4 — Add Repo-Specific Invariants",
        "",
        "Update the generated files with concrete repository details, keeping additions explicit and testable.",
        "",
        "## Step 5 — Add Nested `AGENTS.md` Only If Needed",
        "",
        "Start with the root file only. Add nested files later only for subtrees that repeatedly need stronger local constraints.",
        "",
        "## Step 6 — Maintenance Rule",
        "",
        "- always-on rules stay in root `AGENTS.md`",
        "- focused guidance stays in `openai/skills/*.md`",
        "- `openai/README.md` stays an index and usage note",
        "",
    ])
    return "\n".join(lines)


def generate(spec_path, out_dir):
    spec = yaml.safe_load(Path(spec_path).read_text(encoding="utf-8"))
    out_dir = Path(out_dir)
    openai_dir = out_dir / "openai"
    skills_dir = openai_dir / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)

    (out_dir / "AGENTS.md").write_text(build_agents(spec), encoding="utf-8")
    (out_dir / "AGENTS-GUIDE.md").write_text(build_agents_guide(spec), encoding="utf-8")
    (openai_dir / "README.md").write_text(build_openai_readme(spec), encoding="utf-8")

    for skill in spec["skills"]:
        (skills_dir / skill["filename"]).write_text(build_skill_file(skill), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="Generate AGENTS.md + openai skills bundle from YAML spec.")
    parser.add_argument("--spec", required=True, help="Path to YAML spec")
    parser.add_argument("--out", required=True, help="Output directory")
    args = parser.parse_args()
    generate(args.spec, args.out)


if __name__ == "__main__":
    main()
